package com.example.slidegameslide;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class Duar {
    Bitmap duar[] = new Bitmap[4];
    int duarFrame = 0;
    int duarX, duarY;

    public Duar(Context context) {
        duar[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.duar1);
        duar[1] = BitmapFactory.decodeResource(context.getResources(), R.drawable.duar2);
    }

    public Bitmap getDuar(int duarFrame){
        return duar[duarFrame];
    }
}


