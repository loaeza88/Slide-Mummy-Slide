package com.example.slidegameslide;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.content.res.ResourcesCompat;

import java.util.ArrayList;
import java.util.Random;

public class GameView extends View {

    Bitmap bg, ground, mummy;
    Rect rectBg, rectGround;
    Context context;
    Handler handler;
    final long UPDATE_MILLIS = 30;
    Runnable runnable;
    Paint textPaint = new Paint();
    Paint healthPaint = new Paint();
    float TEXT_SIZE = 120;
    int points = 0;
    int life = 3;
    static int dWidth, dHeight;
    Random random;
    float mummyX, mummyY;
    float oldX;
    float oldMummyX;
    ArrayList<Bomb> bombs;
    ArrayList<Duar> duars;

    public GameView(Context context) {
        super(context);
        this.context = context;
        bg = BitmapFactory.decodeResource(getResources(), R.drawable.bg);
        ground = BitmapFactory.decodeResource(getResources(), R.drawable.ground);
        mummy = BitmapFactory.decodeResource(getResources(), R.drawable.mummy);
        Display display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        dWidth = size.x;
        dHeight = size.y;
        rectBg = new Rect(0,0,dWidth, dHeight);
        rectGround = new Rect(0, dHeight - ground.getHeight(), dWidth, dHeight);
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        };
        textPaint.setColor(Color.rgb(255, 165, 0));
        textPaint.setTextSize(TEXT_SIZE);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTypeface(ResourcesCompat.getFont(context, R.font.kenney_blocks));
        healthPaint.setColor(Color.GREEN);
        random = new Random();
        mummyX = dWidth / 2 - mummy.getWidth() / 2;
        mummyY = dHeight - ground.getHeight() - mummy.getHeight();
        bombs = new ArrayList<>();
        duars = new ArrayList<>();
        for (int i=0; i<3; i++){
            Bomb bomb = new Bomb(context);
            bomb.add(bomb);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawBitmap(bg, null, rectBg, null);
        canvas.drawBitmap(ground, null, rectGround, null);
        canvas.drawBitmap(mummy, mummyX, mummyY, null);
        for (int i=0; i<bombs.size(); i++){
            canvas.drawBitmap(bombs.get(i).getBomb(bombs.get(i).bombFrame), bombs.get(i).bombX, bombs.get(i).bombY, null);
            bombs.get(i).bombFrame++;
            if (bombs.get(i).bombFrame > 2){
                bombs.get(i).bombFrame = 0;
            }
            bombs.get(i).bombY += bombs.get(i).bombVelocity;
            if (bombs.get(i).bombY + bombs.get(i).getBombHeight() >= dHeight - ground.getHeight()){
                points += 10;
                Duar duar = new Duar(context);
                duar.duarX = bombs.get(i).bombX;
                duar.duarY = bombs.get(i).bombY;
                duars.add(duar);
                bombs.get(i).resetPosition();
            }
        }

        for (int i=0; i < bombs.size(); i++){
            if (bombs.get(i).bombX + bombs.get(i).getBombWidth() >= mummyX
            && bombs.get(i).bombX <= mummyX + mummy.getWidth()
            && bombs.get(i).bombY + bombs.get(i).getBombWidth() >= mummyY
            && bombs.get(i).bombY + bombs.get(i).getBombWidth() <= mummyY + mummy.getHeight()){
                life--;
                bombs.get(i).resetPosition();
                if (life == 0) {
                    Intent intent = new Intent(context, GameOver.class);
                    intent.putExtra("points", points);
                    context.startActivity(intent);
                    ((Activity) context).finish();
                }
            }
        }

        for (int i=0; i< duars.size(); i++){
            canvas.drawBitmap(duars.get(i).getDuar(duars.get(i).duarFrame), duars.get(i).duarX,
                    duars.get(i).duarY, null);
            duars.get(i).duarFrame++;
            if (duars.get(i).duarFrame > 3){
                duars.remove(i);
            }
        }

        if (life ==2){
            healthPaint.setColor(Color.YELLOW);
        } else if (life ==1){
            healthPaint.setColor(Color.RED);
        }
        canvas.drawRect(dWidth-200, 30, dWidth-200+60*life, 80, healthPaint);
        canvas.drawText("" + points, 20, TEXT_SIZE, textPaint);
        handler.postDelayed(runnable, UPDATE_MILLIS);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();
        if (touchY >= mummyY) {
            int action = event.getAction();
            if(action == MotionEvent.ACTION_DOWN) {
                oldX = event.getX();
                oldMummyX = mummyX;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                float shift = oldX - touchX;
                float newMummyX = oldMummyX - shift;
                if (newMummyX <= 0)
                    mummyX = 0;
                else if (newMummyX >= dWidth - mummy.getWidth())
                    mummyX = dWidth - mummy.getWidth();
                else
                    mummyX = newMummyX;
            }
        }
        return true;
    }
}
